<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Forensics</title>
        <link rel="stylesheet" type="text/css" href="styles.css" />
        <script type="text/javascript" src="jquery.js"></script>
        <script type="text/javascript" src="script.js"></script>
    </head>
    <body>
        <div class="main">
        <nav>
    <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Add User</a>
        <!-- First Tier Drop Down -->
        <!--ul>
            <li><a href="#">Add Administrator</a></li>
            <li><a href="#">Add Forensic officer</a></li>
            <li><a href="#">Add Forensic practitioner</a></li>
            <li><a href="#">Add student</a></li>
            <li><a href="#">Add guest</a></li>
        </ul-->        
        </li>
        <li><a href="#">Remove</a>
        <li><a href="#">Search</a></li>
        <li><a href="#" id="logout">Logout</a></li>
    </ul>
</nav>
            </div>  
    </body>
</html>
